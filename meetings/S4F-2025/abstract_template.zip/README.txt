Instructions for preparing an abstract:

- Edit the file prato_sample_abstract.tex by
  suitably changing authors, affiliations,
  abstract text, and references. Please relate
  authors to affiliations via the "footnote"
  mechanism as indicated in the template -
  unless there is only a single affiliation.
  Please number references like [1], [2]
  directly in the text, and order them appropriately
  in the body of references. Please do NOT use
  cross-referencing commands like \cite, \ref,
  etc. - this may cause trouble if the same label
  accidentally happens to occur in different abstracts.

- Please send the thus-edited file as an e-mail
  attachment to
  duenweg@mpip-mainz.mpg.de
  subject: Abstract for meeting "Multiphase"

- We plan to use the files wrapper.tex and macros.tex
  to create a simple book of abstracts. If you want
  to check your abstract before submission, you can
  do so by running
  latex wrapper.tex
        (which in turn calls macros.tex and
        prato_sample_abstract.tex)
  and looking at the output wrapper.dvi.
  There is no need for you to edit anything in
  macros.tex of wrapper.tex - unless you change the
  file name of your abstract, in which case you should
  also change the corresponding entry in wrapper.tex.

- If you do not have Latex available, you do not need to
  install it - just submit what you believe is correct.
  Most likely the formatting will be OK, or easily fixable
  by us - if not, we will let you know.

- If you have any technical difficulties, do not
  hesitate to contact us.
